# Fleet Pattern Library Migration Plan

Migrate generic UI primitives in `styles.css` / `index.html` to use Boston's Fleet pattern library classes (loaded via `https://patterns.boston.gov/css/public.css`). Keep app-specific UI (modal, toast, notify footer, demo panel, status logic) custom.

**Reference for all class names**: `patterns-reference.md` (grep by component name).

**Estimated total cut**: ~400-500 lines of CSS, ~35% of `styles.css`.

---

## Step 1 — Button consolidation

**Goal**: Replace 5 reimplemented teal/outlined buttons with Fleet's `.btn`.

**Affected**:

- `index.html`: `#search-btn`, `#notify-save-btn`, `#modal-submit`, `#notification-prefs-save-btn` (inside `app.js`-rendered prefs panel), `.save-btn` / `.remove-btn` (rendered in `app.js`), `.notify-clear-btn`
- `styles.css`: lines 208-224 (`.search-btn`), 485-516 (`.notify-clear-btn`, `.notify-save-btn`), 635-651 (`.modal-submit-btn`), 814-829 (`.notification-prefs-save-btn`), 917-954 (`.save-btn`, `.remove-btn`)
- `app.js`: any `class="..."` strings that emit these buttons — grep for `save-btn`, `remove-btn`, `notification-prefs-save-btn`, `notify-clear-btn`

**Class map**:
| Old | New | Notes |
|---|---|---|
| `.search-btn` | `class="btn"` | Default Fleet button (teal-ish on hover) |
| `.notify-save-btn` | `class="btn"` | Full-width via container, no special variant |
| `.modal-submit-btn` | `class="btn btn--100"` | `--100` = 100% width |
| `.notification-prefs-save-btn` | `class="btn btn--sm"` | Smaller variant |
| `.save-btn` | `class="btn btn--sm"` | |
| `.remove-btn` | `class="btn btn--sm btn--bordered"` | Outlined variant (see `button--bordered`) |
| `.notify-clear-btn` | Keep custom — it's a text link, not a button. Or use Fleet's `.t--link` if it exists. |

**Verify before deleting CSS**: load `patterns-reference.md` entries for `button--default`, `button--bordered`, `button--charles-blue` and confirm `--sm` / `--100` modifiers exist. If `--100` isn't real, use a wrapping `div` with width or a custom utility.

**Risk**: Hover colors will shift to Fleet's defaults (likely red-on-hover for default button). Visually confirm in browser before deleting custom CSS.

---

## Step 2 — Pagination

**Goal**: Replace custom pagination buttons with Fleet's `.pg` list.

**Affected**:

- `app.js`: pagination rendering function (grep for `pagination-btn`, `pagination-controls`)
- `styles.css`: lines 692-756

**Markup change** (from button-based to `<ul>`-based):

```html
<!-- Old -->
<div class="pagination-controls">
  <button class="pagination-btn">‹</button>
  <button class="pagination-btn active">1</button>
  <button class="pagination-btn">2</button>
</div>

<!-- New -->
<ul class="pg">
  <li class="pg-li pg-disabled pg-first"><span class="pg-li-i">‹</span></li>
  <li class="pg-li"><a class="pg-li-i pg-li-i--link pg-li-i--a" href="#">1</a></li>
  <li class="pg-li"><a class="pg-li-i pg-li-i--link" href="#">2</a></li>
</ul>
```

**Caveat**: Fleet pagination uses `<a href>` links, your app uses `<button>` with JS handlers. Either:

- (a) Use `<a href="#" data-page="N">` and `preventDefault()` in the click handler, or
- (b) Use `<button>` with the same `.pg-li-i` class — verify it styles correctly.

**Keep custom**: page-size selector dropdown (`.page-size-selector`) — Fleet doesn't have an equivalent.

---

## Step 3 — Search form

**Goal**: Replace `.search-input-wrapper` / `.search-input` / `.search-btn` with Fleet's `.sf` form.

**Affected**:

- `index.html` lines 42-56
- `styles.css` lines 188-224

**Markup change**:

```html
<!-- Old -->
<div class="search-container">
  <label for="street-search" class="search-label">Find your parking spot</label>
  <span class="search-hint">...</span>
  <div class="search-input-wrapper">
    <input type="text" id="street-search" class="search-input" placeholder="..." />
    <button id="search-btn" class="search-btn">Search</button>
  </div>
  <div id="search-error" class="search-error"></div>
</div>

<!-- New -->
<div class="search-container">
  <label for="street-search" class="sf-l">Find your parking spot</label>
  <span class="search-hint">...</span>
  <form class="sf" onsubmit="return false;">
    <div class="sf-i">
      <input type="text" id="street-search" class="sf-i-f" placeholder="..." autocomplete="off" />
      <button id="search-btn" class="sf-i-b">Search</button>
    </div>
  </form>
  <div id="search-error" class="search-error"></div>
</div>
```

**Keep custom**: `.search-container` (white card wrapper), `.search-hint` (link styling inside hint text), `.search-error` (error color).

**Verify**: confirm `app.js` event listeners on `#street-search` and `#search-btn` still work after the wrapping `<form>` is added. Add `preventDefault()` on form submit.

---

## Step 4 — CSS variables: KEEP AS-IS (resolved)

Investigated: Fleet's `public.css` has **no `:root { --vars }` block**. All brand hex values (`#091f2f`, `#1871bd`, `#fb4d42`, `#fcb61a`) are baked directly into class selectors, not exposed as custom properties.

**Decision**: Keep all CSS variables in `styles.css` lines 5-20. They're load-bearing — app-specific selectors (modal, notify footer, status badges, demo panel) reference them, and removing them would force hardcoding hex everywhere. No action needed.

---

## Step 5 — Table restructure (biggest win)

**Goal**: Replace the `display: grid` row layout with a real `<table>` using Fleet's responsive table.

**Affected**:

- `app.js`: row rendering (grep for `results-table`, `street-row`, `results-table-header`, `saved-table`, `saved-header`)
- `styles.css`: lines 254-443 (~190 lines), 1156-1213 (~57 lines of mobile rules)
- `index.html`: nothing directly; tables are rendered by JS

**Markup change**:

```html
<!-- Old: CSS grid -->
<div class="results-table">
  <div class="results-table-header">
    <span>Street</span><span>Side</span><span>Schedule</span><span>Alert</span>
  </div>
  <div class="street-row">
    <div class="street-row-info">...</div>
    <div class="street-row-side">...</div>
    <div class="street-row-schedule">...</div>
    <div class="street-row-alert-cell">...</div>
  </div>
</div>

<!-- New: semantic table with responsive collapse -->
<table class="responsive-table responsive-table--horizontal">
  <thead>
    <tr>
      <th>Street</th>
      <th>Side</th>
      <th>Schedule</th>
      <th>Alert</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td data-label="Street">...</td>
      <td data-label="Side">...</td>
      <td data-label="Schedule">...</td>
      <td data-label="Alert"><input type="checkbox" /></td>
    </tr>
  </tbody>
</table>
```

**What this deletes**:

- `.results-table`, `.results-table-header`, `.street-row` and all grid-column rules
- The entire `@media (max-width: 600px)` table-collapse block (Fleet's responsive-table handles it via `data-label` automatically)

**What needs adapting**:

- `.status-badge` / `.next-date` / `.next-date-status` styles still apply _inside_ `<td>` cells — keep them.
- Checkboxes inside cells — verify Fleet's table styling doesn't fight `accent-color`.
- The saved-streets variant (`.saved-table` with different column count) — same approach, just different `<th>` set.
- Row hover backgrounds (`.saved-row.status-danger`, `.pending-removal`) — apply to `<tr>` instead of `.street-row`.

**Risk**: Highest of all steps. Touches data-rendering code in `app.js` and visual layout. Test:

1. Desktop: columns align, hover works, checkboxes clickable
2. Mobile (<600px): cells stack with labels visible via `data-label`
3. Status colors still tint rows
4. Pending-removal strikethrough still works

**Process** (per Q2): Do this work on a **separate branch** so the current grid layout stays intact for comparison. Compare side-by-side in browser before deciding whether to keep Fleet's automatic mobile collapse or preserve the current "hide columns, append side via `::after`" pattern. Two possible outcomes:

- **Adopt Fleet's collapse**: delete the entire `@media (max-width: 600px)` block in `styles.css`.
- **Keep current mobile UX**: use Fleet's `<table>` semantics for desktop but override `.responsive-table` rules in the breakpoint to preserve the existing column-hiding behavior.

---

## Step 6 — Site header (added per Q1: shipping inside boston.gov)

**Goal**: Replace the slim custom `.header` with Fleet's full `header--default` chrome.

**Affected**:

- `index.html` lines 19-24
- `styles.css` lines 37-70 (`.header`, `.header-title`, `.header-subtitle`, `.tab-context-banner`)
- `app.js`: the triple-tap-header gesture that opens the demo panel (grep for `header` event listener) — needs rebinding to a new target

**Markup**: see `patterns-reference.md` → `header--default` (lines 4439+). It's ~55 lines of HTML: bridge logo, "Mayor Wu" text, main nav (Public Notices / Pay and Apply / Feedback / Translate / Search icon), mobile burger menu, expandable search drawer.

**What to fill in**:

- Logo `<img src>` paths need to resolve — use absolute `https://patterns.boston.gov/images/public/logo.svg` and `seal.svg`.
- Main nav `<li class="nv-h-l-i">` entries: decide whether to keep boston.gov's standard links, replace with prototype-specific links, or both.
- "Notify Boston" title: Fleet's header doesn't have a page-title slot inside the header chrome. Options:
  - (a) Drop the page title and let the URL/tab navigation imply it.
  - (b) Add a Fleet `section_header--default` (`<div class="sh"><h1 class="sh-title">Notify Boston</h1></div>`) below the site header.
  - Recommend (b) — gives the page an identity without duplicating site chrome.

**Demo-mode gesture**: the triple-tap target needs to move. Bind it to `.sh-title` (the page title) or hide it behind a query-string flag (`?demo=1`) since gestures on the new header would conflict with the burger menu and search icon.

**Risk**: Medium. The header has its own JS dependencies (`https://patterns.boston.gov/scripts/all.js` — already loaded on line 140) for the burger toggle, search drawer, translate menu. Verify those work after dropping in Fleet's markup.

---

## Step 7 — Tab navigation (added per Q1)

**Goal**: Replace the JS-driven `.tab-nav` / `.tab-btn` with Fleet's CSS-only `tabs--default`.

**Affected**:

- `index.html` lines 27-35 (tab buttons) and 41, 63 (`.tab-content` sections)
- `styles.css` lines 73-131 (tabs + alert badge)
- `app.js`: tab-switching logic (grep for `data-tab`, `tab-btn`, `tab-content`, `active`)

**How Fleet tabs work**: hidden radio inputs control which tab pane is visible via CSS sibling selectors. No JS needed for the switching itself.

**Markup**:

```html
<input id="tabCTRL0" type="radio" name="tab-ctrl" class="tab-ctrl tab-ctrl-0" data-hash="#search" checked />
<input id="tabCTRL1" type="radio" name="tab-ctrl" class="tab-ctrl tab-ctrl-1" data-hash="#my-streets" />
<ul class="tab">
  <li class="tab-li tab-li-0">
    <label for="tabCTRL0" class="tab-li-a tab-li-a-0">Search Parking Regulations</label>
  </li>
  <li class="tab-li tab-li-1">
    <label for="tabCTRL1" class="tab-li-a tab-li-a-1">My Notifications
      <span class="alert-badge" id="alert-badge"></span>
    </label>
  </li>
</ul>
<div class="tab-pc">
  <div class="tab-p tab-p-0">...search content...</div>
  <div class="tab-p tab-p-1">...my-streets content...</div>
</div>
```

**What this deletes**: all `.tab-nav`, `.tab-btn`, `.tab-btn:hover`, `.tab-btn.active`, `.tab-btn.active::after` rules, and the JS tab-switching handler.

**What to preserve**:

- `.alert-badge` (the red `!` dot) — Fleet's `.tab-li-a` can contain arbitrary content, keep the badge as-is inside the `<label>`.
- Hash-based deep linking: Fleet's `data-hash` attribute drives URL hash sync via `scripts/all.js`. Verify it works or wire your own.
- Any logic in `app.js` that runs _on tab change_ (e.g. re-rendering the saved-streets list when the My Notifications tab activates) — listen for `change` on the radio inputs instead of `click` on the buttons.

**Risk**: Medium-high. The radio-input pattern is unfamiliar and the `data-hash` integration with `scripts/all.js` needs testing. Like Step 5, **do this on a branch** and verify deep linking, tab persistence on reload, and any "on tab activate" hooks before merging.

---

## Steps explicitly NOT in this plan

- **Modal / toast / notify-footer / demo-panel / status-indicator / alert-badge / loading spinner**: no Fleet equivalents. Keep custom.
- **Cards** (`.street-card`): Fleet cards are link-cards, semantic mismatch with our data-display cards.

---

## Verification checklist (run after each step)

- [ ] Open `index.html` in browser, no console errors
- [ ] Search flow: type → results render → click checkbox → save modal opens
- [ ] My Notifications tab: shows saved streets, can remove, can clear all
- [ ] Mobile breakpoint (<600px): layout doesn't break
- [ ] Demo panel: triple-tap header still opens it; date sim still works
- [ ] Visually compare against a saved screenshot pre-migration

---

## Open questions before starting

1. Will this prototype eventually ship inside boston.gov? (Affects whether to migrate header/tabs.)

- Yes.

2. Is the responsive-table's automatic mobile collapse acceptable, or does the current "hide columns, append side via `::after`" pattern need to be preserved?

- We should test this in a separate branch.

3. Are the duplicate CSS variables in `styles.css` actually being used anywhere Fleet's vars wouldn't cover? (Quick grep check.)

- go ahead check now
