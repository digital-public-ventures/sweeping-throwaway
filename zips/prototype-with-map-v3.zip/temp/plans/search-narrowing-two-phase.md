# Search result narrowing — two-phase plan

## Status

- **Phase 1 — SHIPPED & verified.** All of the ladder below is implemented in `app.js` and exercised live (mobile + desktop). The narrowing logic was extracted into a shared pure function `narrowToBlocks(streetName, nearestIntersectionName, neighborhood)` so the **map pin reuses the exact same ladder** as the typed-address path (`onPinMoved` → `narrowToBlocks` on an exact address, gated by `ADDRESS_SNAP_METERS`).
- **Sprint-1 bot pass: 36/50 cases ✅.** Living tracker: [`docs/search-test-matrix.csv`](../../docs/search-test-matrix.csv); narrative: [`docs/search-test-cases.md`](../../docs/search-test-cases.md). The 14 failures cluster into four themes (see "Remaining work" at the bottom).
- **Phase 2 — NOT STARTED, awaiting approval.** The ArcGIS exact-segment path (below) is the candidate fix for the "doesn't pin on coarse/long streets" failures.

SAM API details referenced throughout: [`docs/sam-api-reference.md`](../../docs/sam-api-reference.md).

## Problem (original framing)

Search returns too many results for high-intent queries. A numbered address ("122 Commonwealth Ave") returns *every* Commonwealth block because `performSearch` strips the house number and substring-matches. An intersection over-matches because `filterByIntersection` uses `.includes()`, so "Charles St" pulls in "Charles Street South", "Charlesgate East/West", "St Charles St".

## Target behaviors (from the user)

- **Plain street name** (no number) → all blocks for that street. *(Keep current behavior — substring match supports partial typing.)*
- **Numbered address** → generally a single block (1–2 rows: even + odd side), with tolerated edge cases (plazas like Boston City Hall).
- **Intersection** → only blocks that terminate at that corner; up to 2× the number of streets meeting there (even/odd per street).

## Key empirical findings (validated against the live API)

1. **Don't trust `xy_lookup`'s centerline for addresses.** `122 Commonwealth Ave` geocodes correctly (score 100) but `xy_lookup` at that point returns centerline "Public Alley No. 435" — the point is nearer a back alley than the avenue centerline. **Use the geocode response's own `street_name` + `street_number` instead** (clean: "Commonwealth Ave", "122").
2. **CSV block granularity is uneven.** All of Back Bay Commonwealth is *one* CSV block ("Arlington St → Massachusetts Ave", even+odd); Allston Comm Ave has a dozen fine blocks. There is often no fine segment to pin — so "find the CSV block governing this address" is the right model, not "pin a geographic segment."
3. **`planning_neighborhood` matches CSV `dist_name`** ("Back Bay" == "Back Bay"); `mailing_neighborhood` is useless ("Boston"). Neighborhood is a strong disambiguator for coarse streets.
4. **`nearest_intersection_name` is a useful but unreliable narrowing signal** — sometimes an alley, sometimes a real cross-street that *is* a CSV block endpoint. Use it only when it leaves ≥1 row; never as a hard gate.
5. **Side values are 90% Even/Odd** with a descriptive tail (Median, Both, Residential, Boston Common, Inbound/Outbound, blank, "ODD"/"EVEN"). Parity filtering must keep descriptive/blank sides regardless of parity.

---

## Phase 1 — the narrowing ladder (local + one geocode/xy_lookup) — ✅ SHIPPED

Implemented in `app.js` and verified. Sections below describe the shipped design.

### 1. `streetNamesMatch(a, b)` helper

Normalized equality with single-sided street-type drop, replacing `.includes()`:

- `normalizeStreetName` both sides (already lowercases + expands abbreviations + ordinals + directions).
- Equal after normalization → match.
- Allow dropping a trailing street-type word (`street`, `avenue`, `road`, …) from **one** side only, so:
  - `"Beacon"` ↔ `"Beacon St"` ✓ (drop type from one side)
  - `"Beacon St"` ↔ `"Beacon Ave"` ✗ (never strip type from both)
  - `"Charles St"` ↔ `"Charles Street South"` ✗ ("south" isn't a type word)
  - `"Charles St"` ↔ `"Charlesgate East"` ✗

### 2. Rewrite `filterByIntersection` to use `streetNamesMatch`

Replace the four `.includes()` calls with whole-name matching. A block "terminates at the corner" when its `st_name` matches one cross-street AND its `from` or `to` matches the other. This makes the intersection path return only terminating blocks.

### 3. Numbered-address path in `performSearch`

Detection: `isNumberedAddress(q)` = `/^\d+\s+\S/`. Runs the geocode ladder in **precise** mode, which fires from two triggers:

- **Explicit submit** (Search button / Enter) → immediate.
- **Auto-narrow debounce**: 400ms after typing stops (see §6). Users don't have to know to submit.

While typing, the 300ms broad debounce shows instant local results; the 400ms timer then auto-narrows. (Pass `{ precise: true }` from button/Enter/auto-narrow; the 300ms broad debounce calls with no flag.)

**Rule: always return both even and odd sides of each matched block.** We never parity-filter — a block's two rows both pass through every narrowing step (which key off `from`/`to` and `dist_name`, never `side`).

Algorithm:

```
1. matches = await samGeocode(rawQuery)
   - keep top-tier matches (match_score === topScore, score > 0)
   - no matches → fall back to existing local substring search (current behavior)
2. For each top match: base = CSV rows where streetNamesMatch(row.st_name, match.street_name)
   - early-out if base is a single block (one distinct from→to pair) — skip the network
3. narrow (graceful — skip any step that empties the set):
   a. cross-street: xy_lookup(x,y) → nearest_intersection_name → two streets →
      keep base rows whose from/to streetNamesMatch one of them. If ≥1, use it.
   b. else neighborhood: keep base rows where dist_name === match.planning_neighborhood. If ≥1, use it.
   c. else keep the whole-street base.
4. Union across top matches, dedupe by main_id. Sort + render.
   - staleness guard: bail before render if the input changed during the await.
```

Network cost: 1 geocode + 1 xy_lookup per top match (usually 1 match → 2 calls).

### 4. Both-sides rule

No parity filtering anywhere. Each matched block contributes all its CSV rows (typically Even + Odd; sometimes a descriptive/blank side). So a confidently located address yields 1–2 rows for its one block.

### 5. Graceful degradation

Every narrowing step is "apply only if it leaves ≥1 row." A naming mismatch (neighborhood, cross-street) never strands the user — worst case they see the whole-street list (both sides), still far better than today.

### 6. Auto-narrow debounce (two-stage)

The search input fires two timers, both reset on each keystroke:

- **300ms** → `performSearch()` (broad; local for plain names, network for intersections).
- **400ms** → `performSearch({ precise: true })` — only armed when `isNumberedAddress(query)`, since that's the one shape where precise differs. (Originally 1500ms; tuned down to 750 then 400 for snappier auto-narrow.)

Because the auto-narrow is async and automatic, `performAddressSearch` re-reads the input before rendering and bails if it changed (staleness guard).

### Phase 1 test matrix (Playwright, mobile then desktop)

| Query | Expect |
| --- | --- |
| `122 Commonwealth Ave` | 2 rows — Arlington→Mass Ave Even + Odd (neighborhood narrowing; cross-street is an alley → skipped) |
| `200 W 7th St` (finely-blocked) | 2 rows — D St→Dorchester St Even + Odd (cross-street narrowing) |
| typing `122 Commonwealth Ave` then waiting | broad (~20) at 300ms, auto-narrows to 2 by ~700ms — no submit |
| `Commonwealth Ave` (no number) | all Comm Ave blocks (unchanged) |
| `Beacon & Charles` | only blocks terminating at that corner — no Charlesgate / Charles Street South |
| `1 City Hall Square` / default | geocodes but no sweeping rows → graceful "no results" (not a crash, not 20 rows) |
| nonsense (`asdfqwer`) | no results |
| intersection with idiom (`Mt Vernon & Charles`) | still works via local fallback |

---

## Remaining work (from the sprint-1 bot pass — 14/50 failing)

Full detail in [`docs/search-test-matrix.csv`](../../docs/search-test-matrix.csv). Four themes:

1. **Abbreviation expansion** (`Mass Ave`→Massachusetts, `Comm Ave`→Commonwealth, `Dor Ave`→Dorchester) — fails in both the local plain path and SAM (`100 Comm Ave` even geocodes to *Commercial St*). Likely fix: a small alias map applied before search. *Not a Phase 2 concern — a cheap standalone win.*
2. **Substring over-match on short names** (`N St`→614 rows, `E St`→326) — the plain path still uses `.includes()`. Adopt `streetNamesMatch`-style whole-word matching there too, while preserving partial-typing (`Beacon`). *Standalone win.*
3. **Typo tolerance** (`Cheslea St`, `1 Saint Botolph St`) — needs fuzzy matching (Damerau-Levenshtein / token-set) as a fallback. *Standalone.*
4. **Address narrowing doesn't pin on coarse/long streets** (`100 Boylston`→5, `200 Dorchester Ave`→7, `100 Mass Ave`→12, Mass/Comm pin→12) — the nearest-intersection signal is an alley or the street is too long for neighborhood narrowing. **This is exactly what Phase 2 targets.**

## Phase 1.5 — neighborhood narrowing fix (SHIPPED)

The neighborhood rung used **exact** string equality (`dist_name === planning_neighborhood`). SAM returns a single neighborhood ("Brighton") while the CSV often uses a compound district ("Allston/Brighton"), so the rung silently emptied and dropped to whole-street. This is why `1950 Commonwealth` returned all ~19 rows while `122 Commonwealth` (SAM "Back Bay" == CSV "Back Bay") narrowed to 2. Fixed with **containment** matching (`d.includes(n) || n.includes(d)`), excluding the `"Multiple"` catch-all district. Result: `1950 Commonwealth` 19 → 11 (narrows via neighborhood now), `122` unchanged at 2. Caveat: neighborhood is only as tight as the neighborhood is small on that street — Allston/Brighton still spans ~8 Comm Ave blocks, so 11 rows, not a block. That's what the centerline phase below targets. War-story recorded in [`docs/search-results-insights.md`](../../docs/search-results-insights.md).

---

## Phase 2 — centerline containment (feature-flagged, NOT STARTED — awaiting spike)

### The exact-segment approach (original Phase 2) is INVALIDATED — keep the evidence

Pinning the precise ArcGIS segment by house-number range *works* but doesn't help, because the **sweeping CSV is coarser than the street grid on arterials**. Verified live for `1950 Commonwealth Ave`:

- Geocoded point → ArcGIS layer-3 segment **9277** (`R_F_ADD..R_T_ADD` = 1934–1986, contains 1950). Clean single-segment pin. ✓
- Layer 8 for segment 9277 → endpoint intersection **"Commonwealth Ave & South St"**.
- **No Commonwealth Ave row in the sweeping CSV terminates at South St.** The finest CSV block there is "Washington St → Chestnut Hill Ave" (0.71 mi). So the segment maps to no CSV row → the whole path falls back to the Phase 1 ladder → still 11. The exact-segment path cannot do better than the ladder here.

So "pin the exact segment" is the wrong primitive. The right primitive is **"which CSV block spans contain this point"** — locate the point along the centerline and test it against block extents.

### Target behavior (decided)

- Finely-blocked street → the one covering block (2 rows, both sides) — as today.
- **Arterial with overlapping rules → return only the TIGHTEST true match: among the blocks whose span covers the point, the one with the smallest `miles` value** (the most-local stretch, not the whole-avenue median rule). Return both sides of that block. We do *not* dump all overlapping rules on the user.
  - e.g. 1950 Comm is covered by both "Arlington→Chestnut Hill Ave" (median, 4.76 mi) and "Washington→Chestnut Hill Ave" (0.71 mi); we return only the 0.71-mi block.

### The primitive: locate point on centerline, test block spans

Two candidate methods to get the point's position relative to block extents. **Method A is the correctness oracle; Method B is the cheap path adopted only where a measured success criterion says it matches A.**

**Method A — cross-street ordering (robust, no scale assumptions).**
1. geocode → point `P`, street `S`; `base` = CSV rows for `S`.
2. collect distinct `from`/`to` cross-streets; resolve each to coords via `intersection_lookup("S and X")`. **Cache per street** (~12 calls for Comm Ave, once).
3. fetch `S`'s centerline polyline from ArcGIS layer 3 (`outSR=4326`); compute the along-line measure of `P` and of each cross-street point (locate-point-on-line).
4. block `[from,to]` covers `P` iff `M(from) ≤ M(P) ≤ M(to)`. Among covering blocks pick **min `miles`**; return both sides.

**Method B — `losta`/`hista` linear referencing (cheap, UNPROVEN).**
`losta`/`hista` look like feet-along-centerline (Arlington→Chestnut Hill Ave = `0–25156` ≈ the avenue's ~25,133 ft). *If* they share an origin/scale with the ArcGIS polyline, skip step 2 entirely: compute `M(P)` in feet, test `losta ≤ M(P) ≤ hista`, pick min `miles`.
**Landmine found:** `losta`/`hista` are keyed **per `parent` route**, not globally — COMMO5 and COMMO1 use different origins ("Lake St→Chestnut Hill Ave" is `25139–28753` while the avenue ostensibly ends at `25156`). So B only works within a parent route and needs that route's geometry. This is the main thing the spike must resolve.

### Spike (do this before building either)

Battery of ~10 addresses with known-correct answers: `1950 Commonwealth`, `100 Mass Ave`, `200 Dorchester Ave`, `100 Boylston`, plus side-street controls (`200 W 7th`, `122 Commonwealth`). For each, compute the covering block via **both** A and B and compare to the human-correct block.

- Define the **success criterion** for B empirically from the spike (likely: "B agrees with A when the street is a single contiguous parent route").
- **Adoption rule: use B where it matches A; fall back to A wherever A produces the tighter/correct result.** A is never worse than B by construction (it makes no scale assumption), so A is the floor. If B never reliably beats A on cost-vs-accuracy, drop B.

### Spike results (RAN — both centerline methods INVALIDATED) — `temp/spike-centerline.mjs`

The spike killed the global-centerline-measure primitive that both A and B depend on.

- **A divided arterial has no single centerline.** ArcGIS layer 3 returns **204 segments totaling 79,571 ft for Commonwealth Ave** — ~3× its true ~25,000 ft, because Comm Ave is divided (two roadways + the central mall/carriage roads, all named "Commonwealth Ave"). You cannot assemble one ordered polyline, so a cumulative along-line measure `M` is undefined. Method A computed the 0.888-mi "Brighton Av→Kelton St" block as a **33,624-ft span** — garbage. **Method A invalidated as drafted.**
- **Method B doubly sunk:** `losta`/`hista` use per-`parent` origins (1950's answer is COMMO1, 122's is COMMO5) *and* don't share a scale/origin with any raw measure. `M(P)=76564 ft` (on the broken chain) vs winner `losta/hista=14762/19452`. No calibration rescues this without first solving the centerline problem, which has no solution on divided roads. **Method B invalidated.**

**Constructive alternative the spike found — cross-street proximity (no centerline needed):** rank the CSV's `from`/`to` cross-streets by straight-line distance from the geocoded point; the two nearest bound the local block. Verified:

- `122 Commonwealth` → nearest cross-streets Arlington St (1610 ft), Massachusetts Ave (3299 ft) → bounds **Arlington St → Massachusetts Ave**, the correct tight Back Bay block (2 rows). ✓
- `1950 Commonwealth` → nearest Chestnut Hill Ave (557 ft), then St Thomas Moore Rd (2825 ft) **and** Lake St (2841 ft) — a **16-ft tie**. The address sits essentially *on* Chestnut Hill Ave; which adjacent block is correct is genuinely ambiguous without side/direction reasoning. This is the irreducible last mile.

### Revised recommendation (post-spike)

1. **Drop the centerline-measure approach (A and B both).** Don't build polyline assembly or `losta`/`hista` referencing — they don't work on the divided arterials we were trying to fix.
2. **If pursuing further, prototype cross-street proximity instead:** geocode → rank resolved cross-streets by distance to the point → covering block = bounded by the two nearest → among matching CSV blocks pick min `miles` → both sides. Cheap (only `intersection_lookup`s, cacheable per street), robust to parallel roadways, no ArcGIS centerline.
3. **Accept the ambiguity floor:** addresses sitting on top of a major intersection may legitimately surface 2 candidate blocks; a tie within ~X ft should return both rather than guess.
4. **Weigh marginal value honestly:** 122 is *already* solved by the shipped neighborhood rung. The net new value of proximity is on large neighborhoods (Allston/Brighton: 11 rows → ~2), not on small ones. Decide whether that delta justifies the per-query `intersection_lookup` fan-out before building.

### Cross-street proximity — BUILT (no feature flag)

Shipped in `app.js` as the **first (tightest) rung** of `narrowAddressMatch`, ahead of the existing nearest-intersection → neighborhood → whole-street ladder (which remains the fallback, and still backs the map-pin path via `narrowToBlocks`).

- `narrowByCrossStreetProximity(streetName, base, point)`: resolve each distinct `from`/`to` cross street via `samIntersectionLookup` (cached per street in `_crossStreetPointCache`), rank by `distanceFeet` to the geocoded point, take the nearest cross street, then among blocks touching it pick the one whose *other* endpoint is nearest. `CROSS_STREET_TIE_FEET = 250` returns all blocks whose far endpoint is within the tie window (the on-intersection ambiguity floor). Always both sides. Returns `null` (→ ladder) when <2 cross streets resolve.
- **No feature flag** (per decision); latency of the per-query `intersection_lookup` fan-out is a known follow-up. Caching makes repeat queries on the same street free.
- **Verified end-to-end** (Playwright, 390×844) + live-API replica:
  - `122 Commonwealth` → **2** (Arlington→Mass Ave). `1950 Commonwealth` → **4** (3-way tie at Chestnut Hill Ave, down from 19). `100 Boylston` → **2** (Tremont→Charles + Washington→Tremont tie). `200 Dorchester Ave` → **1** (East Eighth→Old Colony).

**Latency follow-up (deferred):** N `intersection_lookup` calls per query (≈12 for Comm Ave) on a cold street. Options when we get to it: precompute/ship a static cross-street→coord table for the ~CSV street set, parallel-batch (already `Promise.all`), or only fan out the few cross streets nearest the geocoded point.

### Feature flag + harness

- `localStorage`-backed boolean, surfaced as a checkbox in the existing map debug panel, readable as a module flag. Off → Phase 1 ladder; on → centerline path with the ladder as final fallback.
- Comparison harness logs row counts + chosen block (and `miles`) for ladder vs. A vs. B side-by-side across the battery, same approach as the original hybrid benchmark. Decide adoption from the numbers.

### Known risks to bake in

- **Divided roads:** Comm Ave has a median + service-road centerlines; projection must pick the main line, not a service road (filter layer-3 segments, or pick the nearest/longest).
- **Cross-street resolution failures (A):** an unresolvable `from`/`to` degrades that block to "can't place" → fall back to the neighborhood rung, never strand.
- **Per-parent station origins (B):** the COMMO5/COMMO1 issue above — must segment the comparison by `parent`.
- **More network calls:** geocode + (A: N cached intersection lookups + 1 centerline fetch) or (B: 1 centerline fetch). Cache per street aggressively.
