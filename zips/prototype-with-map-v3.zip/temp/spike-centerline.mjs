// Centerline-narrowing spike. Method A (cross-street ordering, the oracle) vs
// Method B raw signal (losta/hista linear referencing). Run: node temp/spike-centerline.mjs
import fs from 'node:fs';

// ---------- CSV ----------
const lines = fs.readFileSync('street-sweeping.csv', 'utf8').split('\n').filter(Boolean);
const hdr = lines[0].split(',');
const rows = lines.slice(1).map((l) => {
  const c = l.split(',');
  const o = {};
  hdr.forEach((h, i) => (o[h] = c[i]));
  return o;
}).filter((r) => r.main_id && r.st_name);

// ---------- name matching (mirrors app.js) ----------
const MAP = { st:'street',str:'street',ave:'avenue',av:'avenue',dr:'drive',drv:'drive',rd:'road',blvd:'boulevard',boul:'boulevard',ln:'lane',ct:'court',crt:'court',pl:'place',plc:'place',cir:'circle',circ:'circle',ter:'terrace',terr:'terrace',hwy:'highway',pkwy:'parkway',pky:'parkway',sq:'square',wy:'way',pk:'park','1st':'first','2nd':'second','3rd':'third','4th':'fourth','5th':'fifth','6th':'sixth','7th':'seventh','8th':'eighth','9th':'ninth',w:'west',e:'east',n:'north',s:'south' };
const norm = (s) => (s || '').toLowerCase().split(/\s+/).map((w) => MAP[w] || w).join(' ');
const TYPE = new Set(['street','avenue','road','place','drive','boulevard','lane','court','circle','terrace','highway','parkway','square','way','park']);
const strip = (n) => { const w = n.split(' '); return (w.length > 1 && TYPE.has(w[w.length - 1])) ? w.slice(0, -1).join(' ') : n; };
const match = (a, b) => { const na = norm(a), nb = norm(b); if (!na || !nb) return false; if (na === nb) return true; return strip(na) === nb || na === strip(nb); };

// ---------- geo helpers ----------
const FT_PER_DEG_LAT = 364567;
const ftPerDegLng = (lat) => FT_PER_DEG_LAT * Math.cos((lat * Math.PI) / 180);
// project lng/lat to local feet plane around an anchor lat
const toFt = (lng, lat, lat0) => [lng * ftPerDegLng(lat0), lat * FT_PER_DEG_LAT];

// distance from point to segment + the parametric t (0..1) of the projection
function projInfo(px, py, ax, ay, bx, by) {
  const dx = bx - ax, dy = by - ay;
  const len2 = dx * dx + dy * dy || 1e-9;
  let t = ((px - ax) * dx + (py - ay) * dy) / len2;
  t = Math.max(0, Math.min(1, t));
  const cx = ax + t * dx, cy = ay + t * dy;
  const dist = Math.hypot(px - cx, py - cy);
  return { dist, t };
}

// cumulative measure (ft) of the nearest point on an ordered chain of [lng,lat]
function measureAlong(chain, lng, lat, lat0) {
  const [px, py] = toFt(lng, lat, lat0);
  let cum = 0, best = { dist: Infinity, measure: 0 };
  for (let i = 0; i < chain.length - 1; i++) {
    const [ax, ay] = toFt(chain[i][0], chain[i][1], lat0);
    const [bx, by] = toFt(chain[i + 1][0], chain[i + 1][1], lat0);
    const seglen = Math.hypot(bx - ax, by - ay);
    const { dist, t } = projInfo(px, py, ax, ay, bx, by);
    if (dist < best.dist) best = { dist, measure: cum + t * seglen };
    cum += seglen;
  }
  return best; // { dist (ft off-line), measure (ft along) }
}

// greedily chain segment paths into one ordered polyline
function chainPaths(paths) {
  if (!paths.length) return [];
  const used = new Array(paths.length).fill(false);
  let chain = paths[0].slice(); used[0] = true;
  const endDist = (p, q) => Math.hypot(p[0] - q[0], p[1] - q[1]);
  for (let n = 1; n < paths.length; n++) {
    let bestI = -1, bestRev = false, bestAtTail = true, bestD = Infinity;
    const head = chain[0], tail = chain[chain.length - 1];
    for (let i = 0; i < paths.length; i++) {
      if (used[i]) continue;
      const p = paths[i], s = p[0], e = p[p.length - 1];
      const cands = [
        { d: endDist(tail, s), rev: false, atTail: true },
        { d: endDist(tail, e), rev: true,  atTail: true },
        { d: endDist(head, e), rev: false, atTail: false },
        { d: endDist(head, s), rev: true,  atTail: false },
      ];
      for (const c of cands) if (c.d < bestD) { bestD = c.d; bestI = i; bestRev = c.rev; bestAtTail = c.atTail; }
    }
    if (bestI < 0) break;
    used[bestI] = true;
    let p = paths[bestI].slice(); if (bestRev) p.reverse();
    if (bestAtTail) chain = chain.concat(p); else chain = p.concat(chain);
  }
  return chain;
}

// ---------- network ----------
const SAM = 'https://api.sam.boston.gov';
const ARC = 'https://gisportal.boston.gov/arcgis/rest/services/SAM/Live_SAM_Address/FeatureServer';
const j = async (u) => (await fetch(u)).json();
const geocode = (a) => j(`${SAM}/geocode?address=${encodeURIComponent(a)}`);
const intersection = (s) => j(`${SAM}/intersection_lookup?intersection=${encodeURIComponent(s)}`);

const ARC_TYPE = { st:'ST',street:'ST',ave:'AVE',avenue:'AVE',rd:'RD',road:'RD',dr:'DR',drive:'DR',blvd:'BLVD',boulevard:'BLVD',pkwy:'PKWY',parkway:'PKWY',ter:'TER',terrace:'TER',pl:'PL',place:'PL',ct:'CT',court:'CT',cir:'CIR',circle:'CIR',sq:'SQ',square:'SQ',ln:'LN',lane:'LN',hwy:'HWY',highway:'HWY',way:'WAY' };
function arcQuery(csvName) {
  const toks = csvName.trim().split(/\s+/);
  let pre = null;
  if (['W','E','N','S'].includes(toks[0])) pre = toks.shift();
  const typeTok = toks.pop().toLowerCase().replace('.', '');
  const stType = ARC_TYPE[typeTok] || typeTok.toUpperCase();
  const stName = toks.join(' ').toUpperCase();
  let where = `ST_NAME='${stName.replace(/'/g, "''")}' AND ST_TYPE='${stType}'`;
  if (pre) where += ` AND PRE_DIR='${pre}'`;
  return where;
}
async function fetchCenterline(csvName) {
  const where = arcQuery(csvName);
  const u = `${ARC}/3/query?where=${encodeURIComponent(where)}&outFields=SEGMENT_ID&returnGeometry=true&outSR=4326&f=json`;
  const d = await j(u);
  const paths = [];
  for (const f of (d.features || [])) for (const p of (f.geometry?.paths || [])) paths.push(p);
  return chainPaths(paths);
}

// ---------- the spike ----------
async function analyze(address) {
  const out = [`\n========== ${address} ==========`];
  const geo = await geocode(address);
  if (!geo.length) { out.push('  no geocode'); return out.join('\n'); }
  const top = geo[0];
  const street = top.street_name;
  const P = { lng: top.matching_address_x, lat: top.matching_address_y };
  out.push(`  geocode: ${top.matching_address_full}  (score ${top.match_score}, nbhd ${top.planning_neighborhood})`);

  const base = rows.filter((r) => match(r.st_name, street));
  const distinctBlocks = [...new Set(base.map((r) => `${r.from}|${r.to}`))];
  out.push(`  CSV rows for "${street}": ${base.length}  (distinct blocks: ${distinctBlocks.length})`);
  if (distinctBlocks.length <= 1) { out.push('  single block — nothing to narrow'); return out.join('\n'); }

  const chain = await fetchCenterline(street);
  if (chain.length < 2) { out.push(`  !! could not assemble centerline (where: ${arcQuery(street)})`); return out.join('\n'); }
  const lat0 = P.lat;
  const mP = measureAlong(chain, P.lng, P.lat, lat0);
  out.push(`  centerline: ${chain.length} pts, total ~${Math.round(measureAlong(chain, chain[chain.length-1][0], chain[chain.length-1][1], lat0).measure)} ft;  M(P)=${Math.round(mP.measure)} ft  (off-line ${mP.dist.toFixed(0)} ft)`);

  // resolve each distinct cross street → measure
  const crossNames = [...new Set(base.flatMap((r) => [r.from, r.to]).filter((x) => x && !/dead end/i.test(x)))];
  const mCross = {};
  for (const cs of crossNames) {
    try {
      const r = await intersection(`${street} and ${cs}`);
      if (r.length) mCross[cs] = measureAlong(chain, r[0].matching_intersection_x, r[0].matching_intersection_y, lat0).measure;
    } catch {}
  }

  // Method A: blocks whose [from,to] span covers M(P); pick min miles
  const covering = [];
  for (const blk of distinctBlocks) {
    const [from, to] = blk.split('|');
    const mf = mCross[from], mt = mCross[to];
    if (mf == null || mt == null) continue;
    const lo = Math.min(mf, mt), hi = Math.max(mf, mt);
    if (mP.measure >= lo - 50 && mP.measure <= hi + 50) {
      const r = base.find((x) => x.from === from && x.to === to);
      covering.push({ from, to, miles: parseFloat(r.miles) || 0, span: Math.round(hi - lo) });
    }
  }
  covering.sort((a, b) => a.miles - b.miles);
  out.push(`  Method A — covering blocks (${covering.length}):`);
  for (const c of covering) out.push(`      ${c.from} -> ${c.to}   miles=${c.miles.toFixed(3)}  span≈${c.span}ft`);
  const winner = covering[0];
  if (winner) {
    const sideRows = base.filter((r) => r.from === winner.from && r.to === winner.to);
    out.push(`  >>> A tightest: ${winner.from} -> ${winner.to}  (miles=${winner.miles.toFixed(3)}, ${sideRows.length} rows: sides ${[...new Set(sideRows.map(r=>r.side||'(blank)'))].join('/')})`);
    // Method B raw signal: does the winner's losta/hista bracket M(P)?
    const wr = sideRows[0];
    out.push(`  Method B signal: M(P)=${Math.round(mP.measure)} ft vs winner losta/hista=${wr.losta}/${wr.hista} (parent ${wr.parent})`);
  } else {
    out.push('  Method A: no covering block resolved (cross-street lookups failed?) — would fall back to ladder');
  }
  return out.join('\n');
}

const battery = process.argv.slice(2).length
  ? process.argv.slice(2)
  : ['1950 Commonwealth Ave', '122 Commonwealth Ave', '200 W 7th St'];
for (const a of battery) console.log(await analyze(a));
