# Search result narrowing — two-phase plan

## Status

- **Phase 1 — SHIPPED & verified.** All of the ladder below is implemented in `app.js` and exercised live (mobile + desktop). The narrowing logic was extracted into a shared pure function `narrowToBlocks(streetName, nearestIntersectionName, neighborhood)` so the **map pin reuses the exact same ladder** as the typed-address path (`onPinMoved` → `narrowToBlocks` on an exact address, gated by `ADDRESS_SNAP_METERS`).
- **Sprint-1 bot pass: 36/50 cases ✅.** Living tracker: [`docs/search-test-matrix.csv`](../../docs/search-test-matrix.csv); narrative: [`docs/search-test-cases.md`](../../docs/search-test-cases.md). The 14 failures cluster into four themes (see "Remaining work" at the bottom).
- **Phase 2 — NOT STARTED, awaiting approval.** The ArcGIS exact-segment path (below) is the candidate fix for the "doesn't pin on coarse/long streets" failures.

SAM API details referenced throughout: [`docs/sam-api-reference.md`](../../docs/sam-api-reference.md).

## Problem (original framing)

Search returns too many results for high-intent queries. A numbered address ("122 Commonwealth Ave") returns *every* Commonwealth block because `performSearch` strips the house number and substring-matches. An intersection over-matches because `filterByIntersection` uses `.includes()`, so "Charles St" pulls in "Charles Street South", "Charlesgate East/West", "St Charles St".

## Target behaviors (from the user)

- **Plain street name** (no number) → all blocks for that street. *(Keep current behavior — substring match supports partial typing.)*
- **Numbered address** → generally a single block (1–2 rows: even + odd side), with tolerated edge cases (plazas like Boston City Hall).
- **Intersection** → only blocks that terminate at that corner; up to 2× the number of streets meeting there (even/odd per street).

## Key empirical findings (validated against the live API)

1. **Don't trust `xy_lookup`'s centerline for addresses.** `122 Commonwealth Ave` geocodes correctly (score 100) but `xy_lookup` at that point returns centerline "Public Alley No. 435" — the point is nearer a back alley than the avenue centerline. **Use the geocode response's own `street_name` + `street_number` instead** (clean: "Commonwealth Ave", "122").
2. **CSV block granularity is uneven.** All of Back Bay Commonwealth is *one* CSV block ("Arlington St → Massachusetts Ave", even+odd); Allston Comm Ave has a dozen fine blocks. There is often no fine segment to pin — so "find the CSV block governing this address" is the right model, not "pin a geographic segment."
3. **`planning_neighborhood` matches CSV `dist_name`** ("Back Bay" == "Back Bay"); `mailing_neighborhood` is useless ("Boston"). Neighborhood is a strong disambiguator for coarse streets.
4. **`nearest_intersection_name` is a useful but unreliable narrowing signal** — sometimes an alley, sometimes a real cross-street that *is* a CSV block endpoint. Use it only when it leaves ≥1 row; never as a hard gate.
5. **Side values are 90% Even/Odd** with a descriptive tail (Median, Both, Residential, Boston Common, Inbound/Outbound, blank, "ODD"/"EVEN"). Parity filtering must keep descriptive/blank sides regardless of parity.

---

## Phase 1 — the narrowing ladder (local + one geocode/xy_lookup) — ✅ SHIPPED

Implemented in `app.js` and verified. Sections below describe the shipped design.

### 1. `streetNamesMatch(a, b)` helper

Normalized equality with single-sided street-type drop, replacing `.includes()`:

- `normalizeStreetName` both sides (already lowercases + expands abbreviations + ordinals + directions).
- Equal after normalization → match.
- Allow dropping a trailing street-type word (`street`, `avenue`, `road`, …) from **one** side only, so:
  - `"Beacon"` ↔ `"Beacon St"` ✓ (drop type from one side)
  - `"Beacon St"` ↔ `"Beacon Ave"` ✗ (never strip type from both)
  - `"Charles St"` ↔ `"Charles Street South"` ✗ ("south" isn't a type word)
  - `"Charles St"` ↔ `"Charlesgate East"` ✗

### 2. Rewrite `filterByIntersection` to use `streetNamesMatch`

Replace the four `.includes()` calls with whole-name matching. A block "terminates at the corner" when its `st_name` matches one cross-street AND its `from` or `to` matches the other. This makes the intersection path return only terminating blocks.

### 3. Numbered-address path in `performSearch`

Detection: `isNumberedAddress(q)` = `/^\d+\s+\S/`. Runs the geocode ladder in **precise** mode, which fires from two triggers:

- **Explicit submit** (Search button / Enter) → immediate.
- **Auto-narrow debounce**: 400ms after typing stops (see §6). Users don't have to know to submit.

While typing, the 300ms broad debounce shows instant local results; the 400ms timer then auto-narrows. (Pass `{ precise: true }` from button/Enter/auto-narrow; the 300ms broad debounce calls with no flag.)

**Rule: always return both even and odd sides of each matched block.** We never parity-filter — a block's two rows both pass through every narrowing step (which key off `from`/`to` and `dist_name`, never `side`).

Algorithm:

```
1. matches = await samGeocode(rawQuery)
   - keep top-tier matches (match_score === topScore, score > 0)
   - no matches → fall back to existing local substring search (current behavior)
2. For each top match: base = CSV rows where streetNamesMatch(row.st_name, match.street_name)
   - early-out if base is a single block (one distinct from→to pair) — skip the network
3. narrow (graceful — skip any step that empties the set):
   a. cross-street: xy_lookup(x,y) → nearest_intersection_name → two streets →
      keep base rows whose from/to streetNamesMatch one of them. If ≥1, use it.
   b. else neighborhood: keep base rows where dist_name === match.planning_neighborhood. If ≥1, use it.
   c. else keep the whole-street base.
4. Union across top matches, dedupe by main_id. Sort + render.
   - staleness guard: bail before render if the input changed during the await.
```

Network cost: 1 geocode + 1 xy_lookup per top match (usually 1 match → 2 calls).

### 4. Both-sides rule

No parity filtering anywhere. Each matched block contributes all its CSV rows (typically Even + Odd; sometimes a descriptive/blank side). So a confidently located address yields 1–2 rows for its one block.

### 5. Graceful degradation

Every narrowing step is "apply only if it leaves ≥1 row." A naming mismatch (neighborhood, cross-street) never strands the user — worst case they see the whole-street list (both sides), still far better than today.

### 6. Auto-narrow debounce (two-stage)

The search input fires two timers, both reset on each keystroke:

- **300ms** → `performSearch()` (broad; local for plain names, network for intersections).
- **400ms** → `performSearch({ precise: true })` — only armed when `isNumberedAddress(query)`, since that's the one shape where precise differs. (Originally 1500ms; tuned down to 750 then 400 for snappier auto-narrow.)

Because the auto-narrow is async and automatic, `performAddressSearch` re-reads the input before rendering and bails if it changed (staleness guard).

### Phase 1 test matrix (Playwright, mobile then desktop)

| Query | Expect |
| --- | --- |
| `122 Commonwealth Ave` | 2 rows — Arlington→Mass Ave Even + Odd (neighborhood narrowing; cross-street is an alley → skipped) |
| `200 W 7th St` (finely-blocked) | 2 rows — D St→Dorchester St Even + Odd (cross-street narrowing) |
| typing `122 Commonwealth Ave` then waiting | broad (~20) at 300ms, auto-narrows to 2 by ~700ms — no submit |
| `Commonwealth Ave` (no number) | all Comm Ave blocks (unchanged) |
| `Beacon & Charles` | only blocks terminating at that corner — no Charlesgate / Charles Street South |
| `1 City Hall Square` / default | geocodes but no sweeping rows → graceful "no results" (not a crash, not 20 rows) |
| nonsense (`asdfqwer`) | no results |
| intersection with idiom (`Mt Vernon & Charles`) | still works via local fallback |

---

## Remaining work (from the sprint-1 bot pass — 14/50 failing)

Full detail in [`docs/search-test-matrix.csv`](../../docs/search-test-matrix.csv). Four themes:

1. **Abbreviation expansion** (`Mass Ave`→Massachusetts, `Comm Ave`→Commonwealth, `Dor Ave`→Dorchester) — fails in both the local plain path and SAM (`100 Comm Ave` even geocodes to *Commercial St*). Likely fix: a small alias map applied before search. *Not a Phase 2 concern — a cheap standalone win.*
2. **Substring over-match on short names** (`N St`→614 rows, `E St`→326) — the plain path still uses `.includes()`. Adopt `streetNamesMatch`-style whole-word matching there too, while preserving partial-typing (`Beacon`). *Standalone win.*
3. **Typo tolerance** (`Cheslea St`, `1 Saint Botolph St`) — needs fuzzy matching (Damerau-Levenshtein / token-set) as a fallback. *Standalone.*
4. **Address narrowing doesn't pin on coarse/long streets** (`100 Boylston`→5, `200 Dorchester Ave`→7, `100 Mass Ave`→12, Mass/Comm pin→12) — the nearest-intersection signal is an alley or the street is too long for neighborhood narrowing. **This is exactly what Phase 2 targets.**

## Phase 2 — maximal ArcGIS exact-segment pin (feature-flagged, NOT STARTED — awaiting approval)

Goal: an A/B-comparable, **isolated** path that tries to pin the precise segment via ArcGIS address ranges, so we can measure whether it beats the ladder.

### Feature flag

- `localStorage`-backed boolean, surfaced as a checkbox in the existing map debug panel ("Use ArcGIS exact-segment narrowing"), readable as a module flag. Easy to flip at runtime, no rebuild.
- When off → Phase 1 ladder. When on → ArcGIS path with the ladder as fallback.

### ArcGIS path

1. geocode → `street_name`, `street_number`, point.
2. Query SAM segments layer (`Live_SAM_Address/FeatureServer/3`) for that street; find the segment whose `L_F_ADD..L_T_ADD` or `R_F_ADD..R_T_ADD` range contains the house number → `SEGMENT_ID`.
3. Query intersections layer 8 (`where=SEGMENT_ID=X OR SEGMENT_ID2=X`) → the two endpoint cross-streets.
4. Filter CSV: block on the street where `{from,to}` `streetNamesMatch` `{streetA, streetB}` → exact block.
5. Fallback to the Phase 1 ladder when: no segment range contains the number, or the segment endpoints don't align with any CSV block (the coarse-block case, e.g. Back Bay Comm Ave).

### Known Phase 2 risks

- Coarse CSV blocks (Back Bay Comm Ave) have no matching fine segment → ArcGIS pins a segment that maps to no CSV row → must fall back.
- Segment endpoint names (layer 8) may not match CSV `from`/`to` spelling.
- More network calls (geocode + segment query + intersection query).

### Comparison harness

Run both paths for a battery of addresses, log row counts + chosen blocks side-by-side (same approach used for the original hybrid benchmark), decide whether ArcGIS earns its cost.
