# Finding Boston Cross-Streets and Address Ranges with SAM

This note rolls up the workflow for answering two related questions in Boston:

1. Given an address, such as `200 Dorchester Ave`, find the cross-streets for the block.
2. Given a street block between two cross-streets, find the address ranges on either side.

For Boston, the relevant data family is **SAM**, the City of Boston’s Street and Address Management system.

Useful starting points:

- SAM geocoder docs: https://testgeocoder.boston.gov/
- SAM API base: https://api.sam.boston.gov
- Live SAM Address dataset: https://data.boston.gov/dataset/live-street-address-management-sam-addresses
- Boston Street Segments (SAM System): https://data.boston.gov/dataset/boston-street-segments-sam-system
- SAM ArcGIS FeatureServer, street segments layer: https://gisportal.boston.gov/arcgis/rest/services/SAM/Live_SAM_Address/FeatureServer/3

---

## Core concept

A city street centerline dataset usually breaks each street into block-level **segments**. Each segment has address range fields for the left and right sides of the street.

In Boston’s SAM street segments layer, the key fields include:

```text
SEGMENT_ID
ST_NAME
ST_TYPE
L_F_ADD
L_T_ADD
R_F_ADD
R_T_ADD
```

The range fields mean:

```text
L_F_ADD = left-side from address
L_T_ADD = left-side to address
R_F_ADD = right-side from address
R_T_ADD = right-side to address
```

“Left” and “right” are relative to the direction of the segment geometry, not necessarily compass east/west/north/south.

---

## Question 1: Given an address, how do I find the cross-streets?

Example:

```text
200 Dorchester Ave, Boston, MA
```

### Step 1: Geocode the address with SAM

Use the SAM geocoder to normalize the address and get coordinates / SAM identifiers.

```bash
curl 'https://api.sam.boston.gov/geocode?address=200%20Dorchester%20Ave%2C%20Boston%2C%20MA'
```

The response should return one or more matches, including fields along these lines:

```json
[
  {
    "match_score": 100,
    "matching_address_full": "200 DORCHESTER AVE, BOSTON, MA 02127",
    "matching_address_x": -71.057,
    "matching_address_y": 42.33,
    "street_number": "200",
    "street_name": "Dorchester Ave",
    "sam_id": "..."
  }
]
```

Use the highest-confidence match.

### Step 2: Try reverse geocoding, if sufficient

SAM’s reverse geocoder can return nearby address, centerline, intersection, and district context.

```bash
curl 'https://api.sam.boston.gov/reverse-geocode?x=<matching_address_x>&y=<matching_address_y>'
```

Use:

```text
x = longitude
y = latitude
```

If the reverse response includes enough nearest-intersection / centerline context, this may be sufficient for a lightweight app.

### Step 3: For deterministic block logic, query SAM street segments

For a more reliable answer, query the SAM street segments layer and find the road segment whose address range contains the house number.

Boston’s SAM street segment ArcGIS layer:

```text
https://gisportal.boston.gov/arcgis/rest/services/SAM/Live_SAM_Address/FeatureServer/3
```

Query all Dorchester Ave segments:

```bash
curl 'https://gisportal.boston.gov/arcgis/rest/services/SAM/Live_SAM_Address/FeatureServer/3/query?where=ST_NAME%3D%27DORCHESTER%27%20AND%20ST_TYPE%3D%27AVE%27&outFields=SEGMENT_ID,L_F_ADD,L_T_ADD,R_F_ADD,R_T_ADD,ST_NAME,ST_TYPE&returnGeometry=true&f=json'
```

Then find the segment where the house number `200` falls within either the left-side or right-side range.

```js
function inRange(n, a, b) {
  if (a == null || b == null || a === "" || b === "") return false;

  const x = parseInt(a, 10);
  const y = parseInt(b, 10);

  if (Number.isNaN(x) || Number.isNaN(y)) return false;

  return n >= Math.min(x, y) && n <= Math.max(x, y);
}

const houseNumber = 200;

const matchingSegment = features.find(({ attributes }) =>
  inRange(houseNumber, attributes.L_F_ADD, attributes.L_T_ADD) ||
  inRange(houseNumber, attributes.R_F_ADD, attributes.R_T_ADD)
);
```

### Step 4: Find the cross-streets from the segment endpoints

Once you have the matching Dorchester Ave segment:

1. Take the first and last vertices of the segment geometry.
2. For each endpoint, find other street segments that touch or are very near that endpoint.
3. Exclude the original street, `Dorchester Ave`.
4. The remaining street names are the block’s cross-streets.

Conceptually:

```text
Dorchester Ave segment containing #200
  endpoint A -> touching non-Dorchester street = cross street 1
  endpoint B -> touching non-Dorchester street = cross street 2
```

This is the authoritative GIS approach because it uses the same street segment network that SAM uses to model Boston addresses.

---

## Question 2: Given a block, how do I find the address ranges?

Example:

```text
Dorchester Ave between Cross Street A and Cross Street B
```

### Workflow

1. Geocode or otherwise locate the two intersections:
   - `Dorchester Ave & Cross Street A`
   - `Dorchester Ave & Cross Street B`

2. Query the SAM street segments for `Dorchester Ave`.

3. Find the segment whose geometry connects, touches, or lies between the two intersection points.

4. Read:

```text
L_F_ADD / L_T_ADD
R_F_ADD / R_T_ADD
```

Those are the address ranges for each side of that block.

Example result shape:

```text
Street: Dorchester Ave
From cross street: Cross Street A
To cross street: Cross Street B

Left side range:  201-299
Right side range: 200-298
```

Do not assume odd/even or compass direction without checking the actual segment attributes.

---

## Suggested implementation options

### Option A: API-only / lightweight

Use SAM geocode and reverse-geocode endpoints for quick lookup.

Good for:

- interactive tools
- approximate nearest-intersection display
- address normalization
- quick MVPs

Potential weakness:

- reverse geocoding may return nearest objects, not necessarily the exact block boundaries you want.

### Option B: SAM API + local street segments

Use `api.sam.boston.gov` to normalize addresses, then query the SAM street segments layer or a local copy of that layer for deterministic block logic.

Good for:

- production tools
- exact block/range lookup
- repeatable address-to-cross-street logic

Recommended stack:

- Load SAM street segments into PostGIS.
- Load SAM address points if you also need actual address existence.
- Use the SAM geocoder only for normalization and initial coordinates / identifiers.

### Option C: Fully local GIS

Download the SAM address and street segment datasets from Analyze Boston and keep them refreshed.

Good for:

- bulk processing
- offline analysis
- stable reproducibility
- avoiding API rate limits / API availability issues

---

## PostGIS sketch

Assume you have a `boston_sam_street_segments` table with geometry and address range fields.

Find candidate segments for an address:

```sql
SELECT
  segment_id,
  st_name,
  st_type,
  l_f_add,
  l_t_add,
  r_f_add,
  r_t_add,
  geom
FROM boston_sam_street_segments
WHERE upper(st_name) = upper('DORCHESTER')
  AND upper(st_type) = upper('AVE')
  AND (
    200 BETWEEN LEAST(l_f_add, l_t_add) AND GREATEST(l_f_add, l_t_add)
    OR
    200 BETWEEN LEAST(r_f_add, r_t_add) AND GREATEST(r_f_add, r_t_add)
  );
```

Then find intersecting / touching streets near the selected segment endpoints:

```sql
WITH target AS (
  SELECT *
  FROM boston_sam_street_segments
  WHERE upper(st_name) = upper('DORCHESTER')
    AND upper(st_type) = upper('AVE')
    AND (
      200 BETWEEN LEAST(l_f_add, l_t_add) AND GREATEST(l_f_add, l_t_add)
      OR
      200 BETWEEN LEAST(r_f_add, r_t_add) AND GREATEST(r_f_add, r_t_add)
    )
  LIMIT 1
),
endpoints AS (
  SELECT ST_StartPoint(geom) AS pt FROM target
  UNION ALL
  SELECT ST_EndPoint(geom) AS pt FROM target
)
SELECT DISTINCT
  s.st_name,
  s.st_type
FROM boston_sam_street_segments s
JOIN endpoints e
  ON ST_DWithin(s.geom, e.pt, 5) -- tune distance to match CRS / geometry units
WHERE NOT (
  upper(s.st_name) = upper('DORCHESTER')
  AND upper(s.st_type) = upper('AVE')
);
```

If the geometry is in longitude/latitude rather than a projected CRS, transform it before using meter-based distances:

```sql
ST_DWithin(
  ST_Transform(s.geom, 26986),
  ST_Transform(e.pt, 26986),
  5
)
```

EPSG:26986 is Massachusetts Mainland State Plane meters.

---

## Important caveats

### Address ranges are not the same as actual addresses

Street segment ranges tell you the possible range assigned to a block side. They do not prove that every number in the range exists.

For actual deliverable / real addresses, use the SAM address point dataset.

### Left and right are geometry-relative

`L_*` and `R_*` fields are relative to how the street segment was digitized.

Do not assume:

```text
left = west
right = east
odd = left
even = right
```

That may often be true in practice, but it is not safe as a general rule.

### Some streets have multiple names, suffixes, aliases, or divided geometries

Normalize street names through SAM where possible.

For example, split:

```text
Dorchester Ave
```

into:

```text
ST_NAME = DORCHESTER
ST_TYPE = AVE
```

But rely on SAM’s normalized fields rather than your own parser when possible.

### Intersections may have more than two touching streets

At complex intersections, ramps, medians, divided roads, or skewed geometry, an endpoint may touch several segments. Filter by street class, name, and distance to reduce noise.

---

## Recommended answer for `200 Dorchester Ave`

For a one-off lookup:

1. Call:

```bash
curl 'https://api.sam.boston.gov/geocode?address=200%20Dorchester%20Ave%2C%20Boston%2C%20MA'
```

2. Use the returned `matching_address_x` and `matching_address_y`.

3. Try:

```bash
curl 'https://api.sam.boston.gov/reverse-geocode?x=<matching_address_x>&y=<matching_address_y>'
```

4. If that does not directly return the cross-streets, query SAM street segments for `ST_NAME='DORCHESTER' AND ST_TYPE='AVE'`, find the segment whose `L_*` or `R_*` range contains `200`, and inspect the non-Dorchester street segments touching that segment’s endpoints.

For an app or repeatable workflow, use the SAM geocoder for normalization and a local/PostGIS copy of the SAM street segments for the actual cross-street computation.
