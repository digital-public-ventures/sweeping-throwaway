// SAM explorer — throwaway demo. Click the map, see what SAM tells us,
// see which street-sweeping.csv rows live on that street.

const SAM = "https://api.sam.boston.gov";
const BOSTON_CENTER = [42.3601, -71.0589];

const map = L.map("map").setView(BOSTON_CENTER, 13);
L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
  attribution: '&copy; OpenStreetMap',
}).addTo(map);

// Center pin: a CSS-positioned div inside #map. It stays anchored to the
// visual center of the map frame while the user drags the geographic content
// underneath it.
const centerPin = document.createElement("div");
centerPin.className = "center-pin";
centerPin.innerHTML =
  '<svg viewBox="0 0 24 36" width="24" height="36" aria-hidden="true">' +
  '<path d="M12 0C5.4 0 0 5.4 0 12c0 9 12 24 12 24s12-15 12-24c0-6.6-5.4-12-12-12z" fill="#3388ff" stroke="#fff" stroke-width="2"/>' +
  '<circle cx="12" cy="12" r="4" fill="#fff"/>' +
  '</svg>';
document.getElementById("map").appendChild(centerPin);

map.on("dragend", () => lookup(map.getCenter()));

let rows = [];
fetch("../../street-sweeping.csv")
  .then((r) => r.text())
  .then((t) => { rows = Papa.parse(t, { header: true, skipEmptyLines: true }).data; })
  .catch(() => set("csv", "Failed to load CSV — run a local HTTP server from the repo root."));

document.getElementById("search-form").addEventListener("submit", async (e) => {
  e.preventDefault();
  const q = document.getElementById("search-input").value.trim();
  if (!q) return;
  const [best] = await fetch(`${SAM}/geocode?address=${encodeURIComponent(q)}`).then((r) => r.json());
  if (!best) { set("xy", `No geocode match for "${q}".`); return; }
  const ll = { lat: best.matching_address_y, lng: best.matching_address_x };
  map.setView(ll, 17);
  lookup(ll);
});

async function lookup({ lat, lng }) {
  set("xy", "loading…");
  set("csv", "—");
  let xy;
  try { xy = await fetch(`${SAM}/xy_lookup?x=${lng}&y=${lat}`).then((r) => r.json()); }
  catch (err) { set("xy", `xy_lookup failed: ${err.message}`); return; }

  set("xy", [
    `address:      ${xy.nearest_address_full}`,
    `centerline:   ${xy.nearest_centerline_street_name}`,
    `intersection: ${xy.nearest_intersection_name}  (${Math.round(xy.nearest_intersection_distance_meters_from_input_xy)} m)`,
    `neighborhood: ${xy.mailing_neighborhood}`,
  ].join("\n"));

  showCSVMatches(xy);
}

function showCSVMatches(xy) {
  const street = xy.nearest_centerline_street_name;
  const intersection = xy.nearest_intersection_name || "";
  const houseNumber = parseInt(xy.nearest_address_street_number, 10);
  const parity = Number.isFinite(houseNumber) ? (houseNumber % 2 === 0 ? "Even" : "Odd") : null;

  const onStreet = rows.filter((r) => norm(r.st_name) === norm(street));
  if (!onStreet.length) {
    set("csv", `No CSV rows for "${street}".`);
    return;
  }

  // Mark rows whose `from` or `to` is named in the nearest intersection.
  const crossNames = intersection.split(/\s*&\s*/).filter((s) => norm(s) !== norm(street));
  const isOnBlock = (r) => crossNames.some((c) => norm(c) === norm(r.from) || norm(c) === norm(r.to));

  // textContent only — no innerHTML, no escapeHtml, no XSS.
  const out = document.getElementById("csv");
  out.textContent = "";
  out.className = "result";

  const header = document.createElement("div");
  header.textContent = `house #${xy.nearest_address_street_number} → parity=${parity ?? "?"}   (${onStreet.length} rows on ${street})`;
  out.appendChild(header);

  for (const r of onStreet) {
    const line = document.createElement("div");
    line.className = isOnBlock(r) ? "match" : "row";
    line.textContent =
      `${r.st_name}  ${r.from} → ${r.to}   side=${r.side || "—"}  ` +
      `${r.start_time}–${r.end_time}  (${r.dist_name})`;
    out.appendChild(line);
  }
}

// ---- helpers ----

const SUFFIX = { street:"st", avenue:"ave", av:"ave", road:"rd", place:"pl",
  drive:"dr", boulevard:"blvd", lane:"ln", court:"ct", terrace:"ter",
  parkway:"pkwy", square:"sq", highway:"hwy", circle:"cir" };
const DIR = { west:"w", east:"e", north:"n", south:"s" };

function norm(s) {
  if (!s) return "";
  return s.toLowerCase().replace(/[.,]/g, "").split(/\s+/)
    .map((t) => SUFFIX[t] ?? DIR[t] ?? t).join(" ").trim();
}

function set(id, text) {
  const el = document.getElementById(id);
  el.textContent = text;
}

// Panel toggle — hides the SAM/CSV details so the map can go full-screen.
const toggleBtn = document.getElementById("panel-toggle");
toggleBtn.addEventListener("click", () => {
  const hidden = document.body.classList.toggle("panel-hidden");
  toggleBtn.textContent = hidden ? "Show details" : "Hide details";
  toggleBtn.setAttribute("aria-pressed", String(hidden));
  // Leaflet needs to be told its container changed size, otherwise it renders
  // a stale tile grid.
  setTimeout(() => map.invalidateSize(), 0);
});

lookup({ lat: BOSTON_CENTER[0], lng: BOSTON_CENTER[1] });
