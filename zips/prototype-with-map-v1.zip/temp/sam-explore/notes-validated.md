# Boston SAM — validated reference

Validation done 2026-05-27 by hitting each endpoint. Supersedes [../plans/references/boston_sam_cross_streets_address_ranges.md](../plans/references/boston_sam_cross_streets_address_ranges.md).

## Two services, distinct responsibilities

### 1. `api.sam.boston.gov` — REST wrapper, JSON, no auth

OpenAPI spec lives at <https://api.sam.boston.gov/openapi.yaml> (the human page at `/` is a Redoc render of the same spec). Endpoints:

| Endpoint | Purpose |
|---|---|
| `GET /geocode?address=…` | Address → list of `AddressMatch`. Returns lon/lat (`matching_address_x`, `matching_address_y` in WGS84), SAM ids, neighborhood, ward, trash day, etc. Empty array on no match. |
| `GET /xy_lookup?x=…&y=…` | WGS84 lon/lat → nearest address + nearest centerline + nearest intersection + districts. **This is the "reverse geocode" endpoint.** |
| `GET /intersection_lookup?intersection=A and B` | Intersection name → coords + districts. Accepts ` and ` or ` & `. |
| `GET /addresses_by_zip?zip=…` | All addresses in a ZIP. |
| `GET /address_by_id?sam_id=…` | Pull a single address by SAM id. |
| `GET /parks_lookup` | Boston Parks attributes. |

#### What `/xy_lookup` returns (the useful subset for street sweeping)

```jsonc
{
  "nearest_address_full":        "200 Dorchester St, South Boston, MA 02127",
  "nearest_address_street_name": "Dorchester St",
  "nearest_address_street_number": "200",      // parity → Even/Odd
  "nearest_address_x": -71.0499..., "nearest_address_y": 42.3333...,

  "nearest_centerline_street_name": "Dorchester St",
  "nearest_centerline_x": -71.0500..., "nearest_centerline_y": 42.3334...,

  "nearest_intersection_name":   "Dorchester St & W Seventh St",   // <-- block boundary 1
  "nearest_intersection_x": ..., "nearest_intersection_y": ...,
  "nearest_intersection_distance_meters_from_input_xy": 32.0,

  "mailing_neighborhood": "South Boston",
  "ward": "07", "precinct": "05", "police_district": "C6",
  "trash_day": "F"
}
```

For "what block am I on": you get the street, one cross-street, plus a house number for parity. To get the *other* cross-street you have to either bump along the centerline or hit the ArcGIS segments layer (next section).

### 2. `gisportal.boston.gov/arcgis/rest/services/SAM/Live_SAM_Address/FeatureServer` — raw GIS layers

Service root: `…/Live_SAM_Address/FeatureServer?f=json`. Layers:

| ID | Name | Geometry | Notes |
|---|---|---|---|
| 0 | `SAM_Live_Addresses_tbl` | Point | Every active address. |
| 1 | `SAM_Live_Addresses_With_Primary_tbl` | Point | Same plus building-primary link. |
| 2 | `SAM_Live_Buildings_tbl` | Polygon | Building footprints. |
| 3 | `SAM_Boston_Segments_tbl` | Polyline | **Street block segments with L/R address ranges.** |
| 4 | `CAD_Addresses_Segments_tbl` | Point | CAD/911 join. |
| 8 | `SAM_Live_Intersections_deduplicated_tbl` | Point | **Intersection points with `INTERSECTION_NAME` and the two `SEGMENT_ID`s that meet there.** |

Tables (no geometry, used as lookups): 5 master street names, 6 street aliases, 7 suffix crosswalk.

#### Layer 3 — segments — actual field list (confirmed)

```
OBJECTID         integer
SEGMENT_ID       integer
L_F_ADD          string  (nullable)   left-side from address
L_T_ADD          string  (nullable)   left-side to address
R_F_ADD          string  (nullable)   right-side from address
R_T_ADD          string  (nullable)   right-side to address
STREET_ID        integer
PRE_DIR          string  (nullable)   e.g. "W", "E", "N"
ST_NAME          string               canonical name, e.g. "Dorchester", "Seventh"
ST_TYPE          string               e.g. "AVE", "ST", "RD"
SUF_DIR          string  (nullable)
ALTERNATE_NAME   string  (nullable)   common aliases
CFCC             string               census feature classification
SPEEDLIMIT       smallint
ONEWAY           string               "FT" = one-way in geometry direction, "TF" = reverse
F_ZLEV / T_ZLEV  smallint             elevation level (for overpasses)
FT_DIR / TF_DIR  string               cardinal direction of geometry
SHIELD, HWY_NUM
MUN_L / MUN_R    municipality on each side
NBHD_L / NBHD_R  neighborhood on each side
ZIP_L / ZIP_R    zip on each side
```

Notes:
- Address-range fields are **strings**, not integers — parse before comparison, and they can be `null`.
- "Left" / "right" are relative to the polyline direction; do not assume L = odd or L = west.

#### Layer 8 — intersections — actual field list (confirmed)

```
OBJECTID                        oid
SEGMENT_ID                      integer        # one segment that meets here
STREET_ID                       integer
FULL_STREET_NAME                string         # e.g. "Dorchester St"
SEGMENT_ID2                     integer        # the other segment
STREET_ID2                      integer
FULL_STREET_NAME2               string
INTERSECTION_NAME               string         # e.g. "Dorchester St & W Seventh St"
INTERSECTION_NAME_REVERSE       string
F_ZLEV / T_ZLEV / F_ZLEV2 / T_ZLEV2
```

This is the win: **given a SEGMENT_ID, you can query layer 8 with `where=SEGMENT_ID=X OR SEGMENT_ID2=X` to get the intersection name(s) at its endpoints.** No `ST_StartPoint` / `ST_DWithin` PostGIS dance required.

#### Spatial reference gotcha

Service native SR is `wkid: 102686` (MA State Plane Mainland, **feet**) — *not* EPSG:26986 (meters), as the prior doc claimed.

Easy escape hatch: append `&outSR=4326` to any query and get geometries back in WGS84 lon/lat. That's what the demo in this folder does.

#### Example queries

```bash
# All Dorchester Ave segments, with WGS84 geometry
curl "https://gisportal.boston.gov/arcgis/rest/services/SAM/Live_SAM_Address/FeatureServer/3/query?\
where=ST_NAME%3D'DORCHESTER'%20AND%20ST_TYPE%3D'AVE'&\
outFields=SEGMENT_ID,L_F_ADD,L_T_ADD,R_F_ADD,R_T_ADD,ST_NAME,ST_TYPE,PRE_DIR,ONEWAY&\
returnGeometry=true&outSR=4326&f=json"

# Intersections that touch a given segment
curl "https://gisportal.boston.gov/arcgis/rest/services/SAM/Live_SAM_Address/FeatureServer/8/query?\
where=SEGMENT_ID%3D12345%20OR%20SEGMENT_ID2%3D12345&\
outFields=INTERSECTION_NAME,FULL_STREET_NAME,FULL_STREET_NAME2&\
returnGeometry=true&outSR=4326&f=json"

# Segment nearest to a click point (within ~80 ft buffer)
curl "https://gisportal.boston.gov/arcgis/rest/services/SAM/Live_SAM_Address/FeatureServer/3/query?\
geometry=-71.0499,42.3333&geometryType=esriGeometryPoint&inSR=4326&\
spatialRel=esriSpatialRelIntersects&distance=80&units=esriSRUnit_Foot&\
outFields=SEGMENT_ID,ST_NAME,ST_TYPE,PRE_DIR&\
returnGeometry=false&outSR=4326&f=json"
```

(`ArcGIS REST` supports `distance` + `units` for a buffered intersect — that's our "nearest segment to a tap" primitive.)

## Geocoder behavior worth knowing

- Returns an **array** of `AddressMatch`, sorted by descending `match_score` (0–100). Empty array on no match.
- Auto-corrects common typos and the **numeric-↔-word** number names: `"200 W 7th St"` → `"200 W Seventh St"` at score 100. This is what we want for autocomplete-lite UX.
- Does **not** do prefix completion: `"Dor Ave"` returns `[]`. So an autocomplete-as-you-type experience still needs either Algolia/Elastic on a local copy of the SAM address list, or a paid completion API. Cheap path: ship a static prefix index of all `street_name` values from the CSV (≈ a few hundred unique streets) and only call `/geocode` on submit.
- `matching_address_x` / `_y` are WGS84.

## Reverse-geocode workflow that actually maps to our CSV

For the use case "tap a map → find the row in `street-sweeping.csv`":

1. `GET /xy_lookup?x=<lon>&y=<lat>`
2. From the response, take `nearest_centerline_street_name` and `nearest_address_street_number`.
3. Hit ArcGIS layer 3 with `geometry=<lon>,<lat>&spatialRel=Intersects&distance=80&units=Foot&outSR=4326` to find the **SEGMENT_ID** the user is closest to. (Confirm `ST_NAME` matches step 2.)
4. Hit layer 8 with `where=SEGMENT_ID=X OR SEGMENT_ID2=X` to get the two intersections at that segment's endpoints.
5. CSV match: `st_name == centerline_street_name AND ({from,to} == {intersection_A_other_street, intersection_B_other_street})`. Use a normalizer (lowercase, drop punctuation, collapse `St`/`Street`, `Ave`/`Avenue`) before comparing.
6. The CSV may have one row, two rows (one Even, one Odd), or three (Even/Odd/blank for downtown daily sweep). Use the house number parity to pick the right one.

If step 3 returns more than one segment in the buffer (corners, divided streets), prefer the one whose `ST_NAME` matches the centerline name from step 2.
