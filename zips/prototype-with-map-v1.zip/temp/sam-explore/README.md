# SAM Side Quest

Throwaway exploration. Can Boston's SAM API help pin a tap on a map to a row in `street-sweeping.csv`?

## Run it

```bash
# from repo root
python3 -m http.server 8000
# open http://localhost:8000/temp/sam-explore/
```

Click the map or use the search box. The panel shows what SAM returns plus the matching CSV rows.

## Files

- `index.html` + `app.js` + `app.css` — Leaflet/OSM demo. ~80 lines of JS.
- `notes-validated.md` — what's actually true about the SAM endpoints + ArcGIS layers, after hitting each one. Supersedes [../plans/references/boston_sam_cross_streets_address_ranges.md](../plans/references/boston_sam_cross_streets_address_ranges.md).

## TL;DR of the validation

- `/reverse-geocode` from the suspect doc is fake (404). The real endpoint is `/xy_lookup`.
- `/xy_lookup` already returns `nearest_intersection_name` — one of the two cross-streets, for free. No PostGIS geometry dance needed for the simple case.
- `/geocode` matches `"7th"` to `"Seventh"` natively at score 100, so the "do we need Mapbox for fuzzy?" question is answered: not for the numeric ↔ ordinal case. (It does *not* do prefix completion, so live-as-you-type autocomplete would still need something else.)
- ArcGIS layer 8 (`SAM_Live_Intersections_deduplicated_tbl`) gives you both endpoint intersections of a segment via `where=SEGMENT_ID=X OR SEGMENT_ID2=X` — that's the path if/when we need the *other* cross-street to fully pin a block.
